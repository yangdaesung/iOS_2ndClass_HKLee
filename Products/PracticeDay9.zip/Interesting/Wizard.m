//
//  Wizard.m
//  Interesting
//
//  Created by joy on 2016. 9. 20..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import "Wizard.h"

@implementation Wizard

- (id)windstorm:(id)to{
    NSLog(@"마법사는 %@에게 폭풍을 날린다", to);
    return nil;
}

- (id)magicalAttack:(id)to{
    NSLog(@"마법사는 %@에게 마법을 써서 공격한다", to);
    return nil;
}

- (id)heal:(id)to{
    NSLog(@"마법사는 %@를 치료한다", to);
    return nil;
}

@end
