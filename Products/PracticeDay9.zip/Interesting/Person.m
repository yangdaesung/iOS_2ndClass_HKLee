//
//  Person.m
//  Interesting
//
//  Created by joy on 2016. 9. 20..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import "Person.h"


//구현부
@implementation Person


//method를 구현하는 부분

- (id)speak{
    NSLog(@"말을 한다");
    return nil;
}

- (id)speakTo:(id)someone{
    NSLog(@"%@에게 말을 한다", someone);
    return nil;
}

- (id)think{
    NSLog(@"생각한다");
    return nil;
}

- (id)thinkAbout:(id)something{
    NSLog(@"%@를 생각한다", something);
    return nil;
}

- (id)run{
    NSLog(@"달린다");
    return nil;
}

- (id)runTo:(id)location bySpeed:(id)speed with:(id)someone{
    NSLog(@"%@에 %@의 속도로 %@과 함께 달려간다", location, speed, someone);
    return nil;
}

- (id)write:(id)something{
    NSLog(@"%@를 쓴다", something);
    return nil;
}

- (id)read:(id)something{
    NSLog(@"아침에 %@를 읽는다", something);
    return nil;
}

- (id)sing{
    NSLog(@"노래한다.");
    return nil;
}

- (id)talk{
    NSLog(@"대화를 한다");
    return nil;
}

- (id)talkTo:(id)someone topic:(id)topic language:(id)language{
    NSLog(@"%@에게 %@에 관하여 %@로 얘기한다.", someone, topic, language);
    return nil;
}



@end
