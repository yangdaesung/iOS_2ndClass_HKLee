//
//  Wizard.h
//  Interesting
//
//  Created by joy on 2016. 9. 20..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 * 마법사(Wizard)를 나타내는 클래스.
 * @author Laon
 * @version 0.1
 */
@interface Wizard : NSObject



@property id health;

@property id mana;

@property id physicalPower;

@property id magicalPower;

@property id weapon;


- (id)windstorm:(id)to;

- (id)magicalAttack:(id)to;

- (id)heal:(id)to;


@end
