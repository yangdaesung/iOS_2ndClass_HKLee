//
//  Person.h
//  Interesting
//
//  Created by joy on 2016. 9. 20..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import <Foundation/Foundation.h>


// 정의부, 선언부

/**
 * 사람(Person)을 나타내는 클래스.
 * @author Laon
 * @version 0.1
 */
@interface Person : NSObject


/*--------- 클래스 코드에 객체가 각자 가질 수 있는 상태값을 프로퍼티로 정의 -----------*/

/// @discussion 사람 이름
@property id name;


/// @discussion 사람 나이
@property id age;


/// @discussion 사람 혈액형
@property id bloodtype;



/*----------- method 정의 ----------*/

/// @discussion 말한다.
- (id)speak;


// 파라미터 구현
/**
 * @discussion someone에게 말을 한다.
 * @param someone 말을 하는 대상
 */
- (id)speakTo:(id)someone;


/// @discussion 생각한다.
- (id)think;


/**
 * @discussion something을 생각한다.
 * @param something 생각을 하는 대상
 */
- (id)thinkAbout:(id)something;


/// @discussion 달린다.
- (id)run;


// 여러 개의 매개변수를 갖는 경우
// 'bySpeed'는 꼬리표. runTo bySpeed가 메서드의 이름
/**
 * @discussion location을 향해 speed로 someone과 함께 달린다.
 * @param location 향하는 장소
 * @param speed 달리는 속도
 * @param someone 함께 달리는 사람
 */
- (id)runTo:(id)location bySpeed:(id)speed with:(id)someone;


/**
 * @discussion something을 쓴다.
 * @param something 쓰는 행위의 대상
 */
- (id)write:(id)something;


/**
 * @discussion something을 읽는다.
 * @param something 읽는 행위의 대상
 */
- (id)read:(id)something;


/// @discussion 노래를 부른다.
- (id)sing;


/// @discussion 이야기를 한다.
- (id)talk;


/**
 * @discussion someone과 topic에 대해 language로 이야기한다.
 * @param someone 이야기를 나누는 대상
 * @param topic 이야기의 주제
 * @param language 이야기의 수단이 되는 언어
 */
- (id)talkTo:(id)someone topic:(id)topic language:(id)language;



@end
