//
//  main.m
//  Interesting
//
//  Created by joy on 2016. 9. 20..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Wizard.h"
#import "Warrior.h"
#import "Person.h"



int main(int argc, const char * argv[]) {
  
   
    
    /*----------------- person 클래스 ------------------------------------*/
    
    /*----- person의 변수 me -----*/
    
    // me 객체 생성 및 초기화
    // 객체 생성 'me'라는 변수에 메모리 상 객체의 주소를 넣어준다. 주소는 실행시마다 변경된다.
    // 상태값 set : 객체를 생성하고 프로퍼티에 값을 설정

    Person *me = [[Person alloc] init];
    
    me.name = @"Joy";
    me.age = @33;
    me.bloodtype = @"B";
    
    // %@ 안에 me.name의 값을 넣어준다.
    // 상태값 get : 프로퍼티의 값을 가져옴
    NSLog(@"My name is %@", me.name);
    NSLog(@"My name is %@, Age : %@", me.name, me.age);
    
    
    // 프로퍼티의 접근 값 변경 및 프로퍼티 값 가져오기
    me.name = @"Kate";
    me.age = @20;
    NSLog(@"Name : %@, Age : %@", me.name, me.age);
    
    
    // Person 클래스의 객체가 행위를 할 수 있도록 메서드 호출
    [me thinkAbout:@"비행기"];
    [me speakTo:@"친구"];
    [me write:@"편지"];
    [me read:@"신문"];
    [me runTo:@"한강" bySpeed:@"10km/h" with:me.name];
    
    
    
    
    /*-- person의 변수 jane --*/
    
    // jane 객체 생성 및 초기화
    Person *jane = [[Person alloc] init];
    
    
    // 프로퍼티 값 설정
    jane.name = @"Jane";
    jane.age = @31;
    jane.bloodtype = @"O";
    
    
    // 프로퍼티 값 가져오기
    NSLog(@"내 혈액형은 %@형이고, Jane의 혈액형은 %@형이다.", me.bloodtype, jane.bloodtype);
    NSLog(@"jane의 나이는 %@살이다.", jane.age);
    
    
    // jane 클래스의 객체가 하는 행위인 메서드 호출
    [jane talk];
    [jane speakTo:me.name];
    [jane read:@"일기"];
    
    
    
    
    /*-- person의 변수 tom --*/
    
    // tom 객체 생성 및 초기화
    Person *tom = [[Person alloc] init];
    
    
    // tom 객체의 프로퍼티 값 설정
    tom.name = @"Tom";
    tom.age = @34;
    tom.bloodtype = me.bloodtype;
    
    
    // tom 객체의 프로퍼티 값 가져오기
    NSLog(@"tom의 나이는 %@살이다.", tom.age);
    NSLog(@"tom의 혈액형은 %@형이다.", tom.bloodtype);
    
    
    // 프로퍼티 호출 값 변경 후 가져오기
    tom.name = @"Tommy";
    NSLog(@"Tom은 %@라고 불리기도 한다.", tom.name);
    
    
    // 메서드 호출 - 여러 개의 매개변수
    [tom runTo:@"집" bySpeed:@10 with:@"바람"];
    [tom talkTo:@"친구" topic:@"날씨" language:@"영어"];
    
    
    
    
    
    /*----------------- Warrior class --------------------------------------- */
    
    /*-- warrior의 변수 james --*/
    
    // james 객체 생성 및 구현
    Warrior *james = [[Warrior alloc] init];
    
    
    // 프로퍼티 값 설정
    james.health = @300;
    james.mana = @10;
    james.physicalPower = @30;
    james.magicalPower = @10;
    
    
    // 프로퍼티 값 호출
    NSLog(@"health : %@", james.health);
    NSLog(@"mana : %@", james.mana);
    
    
 
    
    /*-- warrior의 변수 jack --*/
    
    // jack 객체 생성 및 구현
    Warrior *jack = [[Warrior alloc] init];
    
    
    // 프로퍼티 값 설정
    jack.health = @150;
    jack.mana = james.mana;
    jack.physicalPower = @20;
    jack.magicalPower = @20;
    
    
    // 프로퍼티 값 가져오기
    NSLog(@"warrior James의 체력은 %@이다.", james.health);
    NSLog(@"warrior Jack의 마력은 %@이다.", jack.magicalPower);
    
    
    // 메서드 호출
    [james physicalAttack:me.name];
    [james physicalAttack:jane.name];
    [james physicalAttack:@"wizard"];
    
    
    
    
    
    /*---------------------- Wizard class ----------------------------- */
    
    /*-- Wizard의 변수 harry --*/
    
    // 객체 생성 및 구현
    Wizard *harry = [[Wizard alloc] init];
    
    
    // 프로퍼티 값 설정
    harry.health = @400;
    harry.mana = @30;
    harry.physicalPower = @50;
    harry.magicalPower = @15;
    
    
    // 메서드 호출
    [harry windstorm:@"상대방"];
    [harry magicalAttack:james];
    [harry heal:tom.name];
    [harry windstorm:jane.name];
    
    
    
    
    return 0;
}
