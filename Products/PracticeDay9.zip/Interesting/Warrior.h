//
//  Warrior.h
//  Interesting
//
//  Created by joy on 2016. 9. 20..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 * 전사(Warrior)를 나타내는 클래스.
 * @author Laon
 * @version 0.1
 */
@interface Warrior : NSObject


// 체력? 건강 상태를 말하는건가?
@property id health;

// 마나는 대체 무엇인가?
@property id mana;

// 이게 체력인가? 물리적인 힘?
@property id physicalPower;

// 마력. 마법은 모든 캐릭터가 쓸 수 있는거임?
@property id magicalPower;

// 전사가 갖고 있는 무기야 뭐 칼이나 활이나 총인가?
@property id weapon;


- (id)physicalAttack:(id)to;


@end
