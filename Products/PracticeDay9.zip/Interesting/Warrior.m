//
//  Warrior.m
//  Interesting
//
//  Created by joy on 2016. 9. 20..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import "Warrior.h"

@implementation Warrior

- (id)physicalAttack:(id)to{
    NSLog(@"전사는 %@를 공격한다", to);
    return nil;
}


@end
