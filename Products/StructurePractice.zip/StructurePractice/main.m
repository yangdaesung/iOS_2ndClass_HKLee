//
//  main.m
//  StructurePractice
//
//  Created by joy on 2016. 9. 19..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
