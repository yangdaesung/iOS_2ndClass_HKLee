//
//  Person.m
//  StructurePractice
//
//  Created by joy on 2016. 9. 19..
//  Copyright © 2016년 Joy. All rights reserved.
//

#import "Person.h"

@implementation Person

@end
